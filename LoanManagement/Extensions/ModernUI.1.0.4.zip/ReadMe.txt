Modern UI for WPF

CONTENTS
========

FirstFloor.ModernUI.dll
FirstFloor.ModernUI.xml
  The ModernUI binary and XML documentation for .NET 4.5

ModernUIDemo.exe 
  A .NET 4.5 application demonstrating most features of Modern UI for WPF

License\
  License files

net40\
  .NET4 build of Modern UI for WPF
